from robot_webcam import executor

if __name__ == '__main__':
    executor.WebCamExecutor().start()
